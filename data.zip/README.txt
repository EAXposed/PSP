Steps for installation:

1. Enter USB mode on your PSP device.

2. Drag the PSP folder from the archive to the root of your memory card. (If it asks to replace anything, select yes.)

3. Exit usb, navigate to the the game menu and then run CM File Manager PSP.